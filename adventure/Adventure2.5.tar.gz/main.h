extern long ABB[], ATAB[], ATLOC[], BLKLIN, DFLAG, DLOC[], FIXED[], HOLDNG,
		KTAB[], *LINES, LINK[], LNLENG, LNPOSN,
		PARMS[], PLACE[], PTEXT[], RTEXT[], TABSIZ;
extern signed char INLINE[], MAP1[], MAP2[];
